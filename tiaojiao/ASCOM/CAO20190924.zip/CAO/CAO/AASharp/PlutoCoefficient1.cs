namespace AASharp
{
    internal struct PlutoCoefficient1
    {
        internal PlutoCoefficient1(int j, int s, int p)
        {
            J = j;
            S = s;
            P = p;
        }

        public int J { get; }
        public int S { get; }
        public int P { get; }
    }
}
