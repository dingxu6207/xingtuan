namespace AASharp
{
    public enum PlanetaryObject
    {
        MERCURY,
        VENUS,
        MARS,
        JUPITER,
        SATURN,
        URANUS,
        NEPTUNE
    }
}
