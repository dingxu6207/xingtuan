﻿namespace SSHub
{
    partial class SSHubForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxUSB6 = new System.Windows.Forms.CheckBox();
            this.checkBoxUSB5 = new System.Windows.Forms.CheckBox();
            this.checkBoxUSB4 = new System.Windows.Forms.CheckBox();
            this.checkBoxUSB3 = new System.Windows.Forms.CheckBox();
            this.checkBoxUSB2 = new System.Windows.Forms.CheckBox();
            this.checkBoxUSB1 = new System.Windows.Forms.CheckBox();
            this.checkBoxDC6 = new System.Windows.Forms.CheckBox();
            this.checkBoxDC5 = new System.Windows.Forms.CheckBox();
            this.checkBoxDC4 = new System.Windows.Forms.CheckBox();
            this.checkBoxDC3 = new System.Windows.Forms.CheckBox();
            this.checkBoxDC2 = new System.Windows.Forms.CheckBox();
            this.checkBoxDC1 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labelTel = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelWebsite = new System.Windows.Forms.Label();
            this.labelVendor = new System.Windows.Forms.Label();
            this.labelDevice = new System.Windows.Forms.Label();
            this.linkLabel = new System.Windows.Forms.LinkLabel();
            this.comboBoxcomPort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Location = new System.Drawing.Point(320, 186);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdate.TabIndex = 0;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxUSB6);
            this.groupBox1.Controls.Add(this.checkBoxUSB5);
            this.groupBox1.Controls.Add(this.checkBoxUSB4);
            this.groupBox1.Controls.Add(this.checkBoxUSB3);
            this.groupBox1.Controls.Add(this.checkBoxUSB2);
            this.groupBox1.Controls.Add(this.checkBoxUSB1);
            this.groupBox1.Controls.Add(this.checkBoxDC6);
            this.groupBox1.Controls.Add(this.checkBoxDC5);
            this.groupBox1.Controls.Add(this.checkBoxDC4);
            this.groupBox1.Controls.Add(this.checkBoxDC3);
            this.groupBox1.Controls.Add(this.checkBoxDC2);
            this.groupBox1.Controls.Add(this.checkBoxDC1);
            this.groupBox1.Location = new System.Drawing.Point(255, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(232, 168);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Hub Switch";
            // 
            // checkBoxUSB6
            // 
            this.checkBoxUSB6.AutoSize = true;
            this.checkBoxUSB6.Location = new System.Drawing.Point(117, 134);
            this.checkBoxUSB6.Name = "checkBoxUSB6";
            this.checkBoxUSB6.Size = new System.Drawing.Size(48, 16);
            this.checkBoxUSB6.TabIndex = 11;
            this.checkBoxUSB6.Text = "USB6";
            this.checkBoxUSB6.UseVisualStyleBackColor = true;
            // 
            // checkBoxUSB5
            // 
            this.checkBoxUSB5.AutoSize = true;
            this.checkBoxUSB5.Location = new System.Drawing.Point(117, 112);
            this.checkBoxUSB5.Name = "checkBoxUSB5";
            this.checkBoxUSB5.Size = new System.Drawing.Size(48, 16);
            this.checkBoxUSB5.TabIndex = 10;
            this.checkBoxUSB5.Text = "USB5";
            this.checkBoxUSB5.UseVisualStyleBackColor = true;
            // 
            // checkBoxUSB4
            // 
            this.checkBoxUSB4.AutoSize = true;
            this.checkBoxUSB4.Location = new System.Drawing.Point(117, 90);
            this.checkBoxUSB4.Name = "checkBoxUSB4";
            this.checkBoxUSB4.Size = new System.Drawing.Size(48, 16);
            this.checkBoxUSB4.TabIndex = 9;
            this.checkBoxUSB4.Text = "USB4";
            this.checkBoxUSB4.UseVisualStyleBackColor = true;
            // 
            // checkBoxUSB3
            // 
            this.checkBoxUSB3.AutoSize = true;
            this.checkBoxUSB3.Location = new System.Drawing.Point(117, 68);
            this.checkBoxUSB3.Name = "checkBoxUSB3";
            this.checkBoxUSB3.Size = new System.Drawing.Size(48, 16);
            this.checkBoxUSB3.TabIndex = 8;
            this.checkBoxUSB3.Text = "USB3";
            this.checkBoxUSB3.UseVisualStyleBackColor = true;
            // 
            // checkBoxUSB2
            // 
            this.checkBoxUSB2.AutoSize = true;
            this.checkBoxUSB2.Location = new System.Drawing.Point(117, 46);
            this.checkBoxUSB2.Name = "checkBoxUSB2";
            this.checkBoxUSB2.Size = new System.Drawing.Size(48, 16);
            this.checkBoxUSB2.TabIndex = 7;
            this.checkBoxUSB2.Text = "USB2";
            this.checkBoxUSB2.UseVisualStyleBackColor = true;
            // 
            // checkBoxUSB1
            // 
            this.checkBoxUSB1.AutoSize = true;
            this.checkBoxUSB1.Location = new System.Drawing.Point(117, 24);
            this.checkBoxUSB1.Name = "checkBoxUSB1";
            this.checkBoxUSB1.Size = new System.Drawing.Size(48, 16);
            this.checkBoxUSB1.TabIndex = 6;
            this.checkBoxUSB1.Text = "USB1";
            this.checkBoxUSB1.UseVisualStyleBackColor = true;
            // 
            // checkBoxDC6
            // 
            this.checkBoxDC6.AutoSize = true;
            this.checkBoxDC6.Location = new System.Drawing.Point(18, 134);
            this.checkBoxDC6.Name = "checkBoxDC6";
            this.checkBoxDC6.Size = new System.Drawing.Size(42, 16);
            this.checkBoxDC6.TabIndex = 5;
            this.checkBoxDC6.Text = "DC6";
            this.checkBoxDC6.UseVisualStyleBackColor = true;
            // 
            // checkBoxDC5
            // 
            this.checkBoxDC5.AutoSize = true;
            this.checkBoxDC5.Location = new System.Drawing.Point(18, 112);
            this.checkBoxDC5.Name = "checkBoxDC5";
            this.checkBoxDC5.Size = new System.Drawing.Size(42, 16);
            this.checkBoxDC5.TabIndex = 4;
            this.checkBoxDC5.Text = "DC5";
            this.checkBoxDC5.UseVisualStyleBackColor = true;
            // 
            // checkBoxDC4
            // 
            this.checkBoxDC4.AutoSize = true;
            this.checkBoxDC4.Location = new System.Drawing.Point(18, 90);
            this.checkBoxDC4.Name = "checkBoxDC4";
            this.checkBoxDC4.Size = new System.Drawing.Size(42, 16);
            this.checkBoxDC4.TabIndex = 3;
            this.checkBoxDC4.Text = "DC4";
            this.checkBoxDC4.UseVisualStyleBackColor = true;
            // 
            // checkBoxDC3
            // 
            this.checkBoxDC3.AutoSize = true;
            this.checkBoxDC3.Location = new System.Drawing.Point(18, 68);
            this.checkBoxDC3.Name = "checkBoxDC3";
            this.checkBoxDC3.Size = new System.Drawing.Size(42, 16);
            this.checkBoxDC3.TabIndex = 2;
            this.checkBoxDC3.Text = "DC3";
            this.checkBoxDC3.UseVisualStyleBackColor = true;
            // 
            // checkBoxDC2
            // 
            this.checkBoxDC2.AutoSize = true;
            this.checkBoxDC2.Location = new System.Drawing.Point(18, 46);
            this.checkBoxDC2.Name = "checkBoxDC2";
            this.checkBoxDC2.Size = new System.Drawing.Size(42, 16);
            this.checkBoxDC2.TabIndex = 1;
            this.checkBoxDC2.Text = "DC2";
            this.checkBoxDC2.UseVisualStyleBackColor = true;
            // 
            // checkBoxDC1
            // 
            this.checkBoxDC1.AutoSize = true;
            this.checkBoxDC1.Location = new System.Drawing.Point(18, 24);
            this.checkBoxDC1.Name = "checkBoxDC1";
            this.checkBoxDC1.Size = new System.Drawing.Size(42, 16);
            this.checkBoxDC1.TabIndex = 0;
            this.checkBoxDC1.Text = "DC1";
            this.checkBoxDC1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.labelTel);
            this.groupBox2.Controls.Add(this.labelEmail);
            this.groupBox2.Controls.Add(this.labelWebsite);
            this.groupBox2.Controls.Add(this.labelVendor);
            this.groupBox2.Controls.Add(this.labelDevice);
            this.groupBox2.Controls.Add(this.linkLabel);
            this.groupBox2.Location = new System.Drawing.Point(13, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(236, 168);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Vendor";
            // 
            // labelTel
            // 
            this.labelTel.AutoSize = true;
            this.labelTel.Location = new System.Drawing.Point(16, 113);
            this.labelTel.Name = "labelTel";
            this.labelTel.Size = new System.Drawing.Size(101, 12);
            this.labelTel.TabIndex = 64;
            this.labelTel.Text = "WeChat: graycode";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(16, 91);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(155, 12);
            this.labelEmail.TabIndex = 63;
            this.labelEmail.Text = "Email: graycode(at)qq.com";
            // 
            // labelWebsite
            // 
            this.labelWebsite.AutoSize = true;
            this.labelWebsite.Location = new System.Drawing.Point(16, 69);
            this.labelWebsite.Name = "labelWebsite";
            this.labelWebsite.Size = new System.Drawing.Size(53, 12);
            this.labelWebsite.TabIndex = 62;
            this.labelWebsite.Text = "Website:";
            // 
            // labelVendor
            // 
            this.labelVendor.AutoSize = true;
            this.labelVendor.Location = new System.Drawing.Point(16, 47);
            this.labelVendor.Name = "labelVendor";
            this.labelVendor.Size = new System.Drawing.Size(149, 12);
            this.labelVendor.TabIndex = 61;
            this.labelVendor.Text = "Developer: Graycode Team";
            // 
            // labelDevice
            // 
            this.labelDevice.AutoSize = true;
            this.labelDevice.Location = new System.Drawing.Point(16, 25);
            this.labelDevice.Name = "labelDevice";
            this.labelDevice.Size = new System.Drawing.Size(185, 12);
            this.labelDevice.TabIndex = 60;
            this.labelDevice.Text = "Device: Searching device......";
            // 
            // linkLabel
            // 
            this.linkLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.linkLabel.AutoSize = true;
            this.linkLabel.Location = new System.Drawing.Point(75, 69);
            this.linkLabel.Name = "linkLabel";
            this.linkLabel.Size = new System.Drawing.Size(83, 12);
            this.linkLabel.TabIndex = 59;
            this.linkLabel.TabStop = true;
            this.linkLabel.Text = "Graycode Team";
            this.linkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_LinkClicked);
            // 
            // comboBoxcomPort
            // 
            this.comboBoxcomPort.FormattingEnabled = true;
            this.comboBoxcomPort.Location = new System.Drawing.Point(71, 188);
            this.comboBoxcomPort.Name = "comboBoxcomPort";
            this.comboBoxcomPort.Size = new System.Drawing.Size(121, 20);
            this.comboBoxcomPort.TabIndex = 3;
            this.comboBoxcomPort.SelectedIndexChanged += new System.EventHandler(this.comboBoxComPort_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 191);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "Com Port";
            // 
            // SSHubForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(499, 215);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxcomPort);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonUpdate);
            this.Name = "SSHubForm";
            this.Text = "SS Hub Control";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SSHubForm_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBoxUSB6;
        private System.Windows.Forms.CheckBox checkBoxUSB5;
        private System.Windows.Forms.CheckBox checkBoxUSB4;
        private System.Windows.Forms.CheckBox checkBoxUSB3;
        private System.Windows.Forms.CheckBox checkBoxUSB2;
        private System.Windows.Forms.CheckBox checkBoxUSB1;
        private System.Windows.Forms.CheckBox checkBoxDC6;
        private System.Windows.Forms.CheckBox checkBoxDC5;
        private System.Windows.Forms.CheckBox checkBoxDC4;
        private System.Windows.Forms.CheckBox checkBoxDC3;
        private System.Windows.Forms.CheckBox checkBoxDC2;
        private System.Windows.Forms.CheckBox checkBoxDC1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxcomPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelTel;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelWebsite;
        private System.Windows.Forms.Label labelVendor;
        private System.Windows.Forms.Label labelDevice;
        private System.Windows.Forms.LinkLabel linkLabel;
    }
}

