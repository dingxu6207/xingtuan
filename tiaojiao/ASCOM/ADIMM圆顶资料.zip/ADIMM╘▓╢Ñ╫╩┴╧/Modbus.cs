﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASCOM.ADIMM
{
    class Modbus
    {
        /* 
         * Generic Modbus TCP/IP connection.
         * Copyright (C) 2008-2009 Petr Kubanek <petr@kubanek.net>
         *
         * This program is free software; you can redistribute it and/or
         * modify it under the terms of the GNU General Public License
         * as published by the Free Software Foundation; either version 2
         * of the License, or (at your option) any later version.
         *
         * This program is distributed in the hope that it will be useful,
         * but WITHOUT ANY WARRANTY; without even the implied warranty of
         * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
         * GNU General Public License for more details.
         *
         * You should have received a copy of the GNU General Public License
         * along with this program; if not, write to the Free Software
         * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
         */
        private bool debugModbusComm;
		private Int16 transId;
		private char unitId;
        public Modbus ()
        {
	        transId = 1;
	        unitId = 0;
        }

        public void callFunction (char func, void *data, UInt16 data_size, void *reply, UInt16 reply_size)
        {
	        char send_data[8 + data_size];
	        // fill header
	        *((UInt16 *) send_data) = htons (transId);
	        send_data[2] = 0;
	        send_data[3] = 0;
	        *((UInt16 *) (send_data + 4)) = htons (data_size + 2);
	        send_data[6] = unitId;
	        send_data[7] = func;
	        bcopy (data, send_data + 8, data_size);
	        data_size += 8;
	        try
	        {
		        sendData (send_data, data_size);
		        reply_size += 8;
		        char reply_data[reply_size];
		        receiveData (reply_data, reply_size, 50);

		        if (reply_data[7] & 0x80)
		        {
			        std::ostringstream _os;
			        _os << "Error executiong function " << func 
				        << " error code is: 0x" << std::hex << (int) reply_data[8];
			        throw ModbusError (this, _os.str ().c_str ());
		        }
		        else if (reply_data[7] != func)
		        {
		  	        std::ostringstream _os;
			        _os << "Invalid reply from modbus read, reply function is 0x" << std::hex << (int) reply_data[7]
				        << ", expected 0x" << std::hex << (int) func;
			        throw ModbusError (this, _os.str ().c_str ());
		        }
		        bcopy (reply_data + 8, reply, reply_size - 8);
		        transId++;
	        }
	        catch (ConnError err)
	        {
		        logStream (MESSAGE_ERROR) << err << sendLog;
		        throw (err);
	        }
        }

        public void callFunction (char func, Int16 p1, Int16 p2, void *reply, UInt16 reply_size)
        {
	        Int16 req_data[2];
	        req_data[0] = htons (p1);
	        req_data[1] = htons (p2);

	        callFunction (func, req_data, 4, reply, reply_size);
        }

        public void callFunction (char func, Int16 p1, Int16 p2, UInt16 *reply_data, Int16 qty)
        {
	        int reply_size = 1 + qty * 2;
	        char reply[reply_size];

	        callFunction (func, p1, p2, (void *) reply, reply_size);

	        if (reply[0] != qty * 2)
	        {
		        throw ModbusError (this, "Invalid quantity in reply packet!");
	        }

	        char *rtop = reply + 1;

	        for (reply_size = 0; reply_size < qty; reply_size++)
	        {
		        reply_data[reply_size] = ntohs (*((UInt16 *) rtop));
		        rtop += 2;
	        }
        }

        public void readCoils (Int16 start, Int16 size)
        {
	        int reply_size = 1 + (size / 8) + ((size % 8) == 0 ? 0 : 1);
	        char reply_data[reply_size];

	        callFunction (0x01, start, size, reply_data, reply_size);
        }

        public void readDiscreteInputs (Int16 start, Int16 size)
        {
	        int reply_size = 1 + (size / 8) + ((size % 8) == 0 ? 0 : 1);
	        char reply_data[reply_size];

	        callFunction (0x02, start, size, reply_data, reply_size);
        }

        public void readHoldingRegisters (Int16 start, Int16 qty, UInt16 *reply_data)
        {
	        callFunction (0x03, start, qty, reply_data, qty);
        }

        public void readInputRegisters (Int16 start, Int16 qty, UInt16 *reply_data)
        {
	        callFunction (0x04, start, qty, reply_data, qty);
        }

        public void writeHoldingRegister (Int16 reg, Int16 val)
        {
  	        Int16 reply[2];
	        callFunction (0x06, reg, val, reply, 4);
        }

        public void writeHoldingRegisterMask (Int16 reg, Int16 mask, Int16 val)
        {
	        UInt16 old_value;
	        readHoldingRegisters (reg, 1, &old_value);
	        old_value &= ~mask;
	        old_value |= (val & mask);
	        writeHoldingRegister (reg, old_value);
        }

    }
}
