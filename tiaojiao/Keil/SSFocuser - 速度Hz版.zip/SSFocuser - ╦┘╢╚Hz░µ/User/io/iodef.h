#ifndef __IODEF_H
#define	__IODEF_H

#define Focuser_B_DRV8825
//#define Focuser_B_TMC2208
//#define Focuser_C_DRV8825

#include "stm32f10x.h"
/////////////////////////////////////////////////
//Focuser4X4-DRV8825
/////////////////////////////////////////////////

#ifdef Focuser_B_DRV8825

//TEMP�ź�
#define TEMP_GPIO_PORT        GPIOB
#define TEMP_GPIO_CLK         RCC_APB2Periph_GPIOB
#define TEMP_GPIO_PIN         GPIO_Pin_12
//SCLSDA����
// SCL�ź�
#define SCL_GPIO_PORT        GPIOB
#define SCL_GPIO_CLK         RCC_APB2Periph_GPIOB
#define SCL_GPIO_PIN         GPIO_Pin_8

// SDA�ź�
#define SDA_GPIO_PORT        GPIOB
#define SDA_GPIO_CLK         RCC_APB2Periph_GPIOB
#define SDA_GPIO_PIN         GPIO_Pin_9


// SLP�ź�
#define SLP_GPIO_PORT    		GPIOB
#define SLP_GPIO_CLK 	    	RCC_APB2Periph_GPIOB		
#define SLP_GPIO_PIN		    GPIO_Pin_6  

// FLT�ź�
#define FLT_GPIO_PORT    		GPIOB
#define FLT_GPIO_CLK 	    	RCC_APB2Periph_GPIOB		
#define FLT_GPIO_PIN		    GPIO_Pin_5  

// DIR�ź�
#define DIR_GPIO_PORT    		GPIOB
#define DIR_GPIO_CLK 	    	RCC_APB2Periph_GPIOB		
#define DIR_GPIO_PIN		    GPIO_Pin_4                 

// EN�ź�
#define EN_GPIO_PORT    	  GPIOB			              
#define EN_GPIO_CLK 	      RCC_APB2Periph_GPIOB		
#define EN_GPIO_PIN		    	GPIO_Pin_3		        

//STEP�ź� 
#define STEP_GPIO_PORT      GPIOA
#define STEP_GPIO_CLK       RCC_APB2Periph_GPIOA
#define STEP_GPIO_PIN       GPIO_Pin_15

//HOME�ź� 
#define HOME_GPIO_PORT      GPIOA
#define HOME_GPIO_CLK       RCC_APB2Periph_GPIOA
#define HOME_GPIO_PIN       GPIO_Pin_14

//MO,M1,M2����
//M0�ź�
#define M0_GPIO_PORT        GPIOB
#define M0_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M0_GPIO_PIN         GPIO_Pin_13

//M1�ź� 
#define M1_GPIO_PORT        GPIOB
#define M1_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M1_GPIO_PIN         GPIO_Pin_14

//M2�ź� 
#define M2_GPIO_PORT        GPIOA
#define M2_GPIO_CLK         RCC_APB2Periph_GPIOA
#define M2_GPIO_PIN         GPIO_Pin_15

#else

//////////////////////////////////////////////////
//Focuser4X4-TMC2208
//////////////////////////////////////////////////

#ifdef Focuser_B_TMC2208

//TEMP�ź�
#define TEMP_GPIO_PORT        GPIOB
#define TEMP_GPIO_CLK         RCC_APB2Periph_GPIOB
#define TEMP_GPIO_PIN         GPIO_Pin_10
//SCLSDA����
// SCL�ź�
#define SCL_GPIO_PORT        GPIOB
#define SCL_GPIO_CLK         RCC_APB2Periph_GPIOB
#define SCL_GPIO_PIN         GPIO_Pin_8

// SDA�ź�
#define SDA_GPIO_PORT        GPIOB
#define SDA_GPIO_CLK         RCC_APB2Periph_GPIOB
#define SDA_GPIO_PIN         GPIO_Pin_9


// SLP�źţ����ﲻ�ã���Ϊ�˳�����ȷ����
#define SLP_GPIO_PORT    		GPIOB
#define SLP_GPIO_CLK 	    	RCC_APB2Periph_GPIOB		
#define SLP_GPIO_PIN		    GPIO_Pin_4  

// FLT�źţ����ﲻ�ã���Ϊ�˳�����ȷ����
#define FLT_GPIO_PORT    		GPIOB
#define FLT_GPIO_CLK 	    	RCC_APB2Periph_GPIOB		
#define FLT_GPIO_PIN		    GPIO_Pin_5  

// EN�ź�
#define EN_GPIO_PORT    	  GPIOB		              
#define EN_GPIO_CLK 	      RCC_APB2Periph_GPIOB		
#define EN_GPIO_PIN		    	GPIO_Pin_1		        

// DIR�ź�
#define DIR_GPIO_PORT    		GPIOA
#define DIR_GPIO_CLK 	    	RCC_APB2Periph_GPIOA		
#define DIR_GPIO_PIN		    GPIO_Pin_2                 

//STEP�ź� 
#define STEP_GPIO_PORT      GPIOA
#define STEP_GPIO_CLK       RCC_APB2Periph_GPIOA
#define STEP_GPIO_PIN       GPIO_Pin_3

//PDN�ź� 
#define PDN_GPIO_PORT      GPIOA
#define PDN_GPIO_CLK       RCC_APB2Periph_GPIOA
#define PDN_GPIO_PIN       GPIO_Pin_4

//INDEX�ź� 
#define INDEX_GPIO_PORT      GPIOA
#define INDEX_GPIO_CLK       RCC_APB2Periph_GPIOA
#define INDEX_GPIO_PIN       GPIO_Pin_5

//DIAG�ź� 
#define DIAG_GPIO_PORT      GPIOA
#define DIAG_GPIO_CLK       RCC_APB2Periph_GPIOA
#define DIAG_GPIO_PIN       GPIO_Pin_6

//HOME�źţ����ﲻ�ã���Ϊ�˳�����ȷ����
#define HOME_GPIO_PORT      GPIOB
#define HOME_GPIO_CLK       RCC_APB2Periph_GPIOB
#define HOME_GPIO_PIN       GPIO_Pin_6

//MO,M1,M2->MS1,MS2
//M0�ź�
#define M0_GPIO_PORT        GPIOB
#define M0_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M0_GPIO_PIN         GPIO_Pin_0

//M1�ź� 
#define M1_GPIO_PORT        GPIOA
#define M1_GPIO_CLK         RCC_APB2Periph_GPIOA
#define M1_GPIO_PIN         GPIO_Pin_7

//M2�źţ����ﲻ�ã���Ϊ�˳�����ȷ����
#define M2_GPIO_PORT        GPIOB
#define M2_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M2_GPIO_PIN         GPIO_Pin_7

#else

/////////////////////////////////////////////////
//Focuser4X7.8-DRV8825
/////////////////////////////////////////////////

#ifdef Focuser_C_DRV8825

//TEMP�ź�
#define TEMP_GPIO_PORT        GPIOA
#define TEMP_GPIO_CLK         RCC_APB2Periph_GPIOA
#define TEMP_GPIO_PIN         GPIO_Pin_0

//BRST�ź�
#define BRST_GPIO_PORT        GPIOA
#define BRST_GPIO_CLK         RCC_APB2Periph_GPIOA
#define BRST_GPIO_PIN         GPIO_Pin_1

//D1�ź�
#define D1_GPIO_PORT          GPIOA
#define D1_GPIO_CLK           RCC_APB2Periph_GPIOA
#define D1_GPIO_PIN           GPIO_Pin_4

//D2�ź�
#define D2_GPIO_PORT          GPIOA
#define D2_GPIO_CLK           RCC_APB2Periph_GPIOA
#define D2_GPIO_PIN           GPIO_Pin_5

//D3�ź�
#define D3_GPIO_PORT          GPIOA
#define D3_GPIO_CLK           RCC_APB2Periph_GPIOA
#define D3_GPIO_PIN           GPIO_Pin_6

//D4�ź�
#define D4_GPIO_PORT          GPIOA
#define D4_GPIO_CLK           RCC_APB2Periph_GPIOA
#define D4_GPIO_PIN           GPIO_Pin_7

// SCL�ź�
#define SCL_GPIO_PORT        GPIOB
#define SCL_GPIO_CLK         RCC_APB2Periph_GPIOB
#define SCL_GPIO_PIN         GPIO_Pin_10

// SDA�ź�
#define SDA_GPIO_PORT        GPIOB
#define SDA_GPIO_CLK         RCC_APB2Periph_GPIOB
#define SDA_GPIO_PIN         GPIO_Pin_11


// SLP�ź�
#define SLP_GPIO_PORT    	GPIOB
#define SLP_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define SLP_GPIO_PIN		    GPIO_Pin_9  

// FLT�ź�
#define FLT_GPIO_PORT    	GPIOB
#define FLT_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define FLT_GPIO_PIN		    GPIO_Pin_8  

// DIR�ź�
#define DIR_GPIO_PORT    	GPIOB
#define DIR_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define DIR_GPIO_PIN		    GPIO_Pin_7                 

// EN�ź�
#define EN_GPIO_PORT    	  GPIOB			              
#define EN_GPIO_CLK 	      RCC_APB2Periph_GPIOB		
#define EN_GPIO_PIN		    GPIO_Pin_6		        

//STEP�ź� 
#define STEP_GPIO_PORT      GPIOB
#define STEP_GPIO_CLK       RCC_APB2Periph_GPIOB
#define STEP_GPIO_PIN       GPIO_Pin_5

//M0�ź�
#define M0_GPIO_PORT        GPIOB
#define M0_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M0_GPIO_PIN         GPIO_Pin_4

//M1�ź� 
#define M1_GPIO_PORT        GPIOB
#define M1_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M1_GPIO_PIN         GPIO_Pin_3

//M2�ź� 
#define M2_GPIO_PORT        GPIOA
#define M2_GPIO_CLK         RCC_APB2Periph_GPIOA
#define M2_GPIO_PIN         GPIO_Pin_15



// SLP2�ź�
#define SLP2_GPIO_PORT    	  GPIOA
#define SLP2_GPIO_CLK 	      RCC_APB2Periph_GPIOA		
#define SLP2_GPIO_PIN		    GPIO_Pin_14  

// FLT2�ź�
#define FLT2_GPIO_PORT    	  GPIOA
#define FLT2_GPIO_CLK 	      RCC_APB2Periph_GPIOA		
#define FLT2_GPIO_PIN		    GPIO_Pin_13  

// DIR2�ź�
#define DIR2_GPIO_PORT    	  GPIOA
#define DIR2_GPIO_CLK 	      RCC_APB2Periph_GPIOA		
#define DIR2_GPIO_PIN		    GPIO_Pin_12                 

// EN2�ź�
#define EN2_GPIO_PORT    	  GPIOA			              
#define EN2_GPIO_CLK 	      RCC_APB2Periph_GPIOA		
#define EN2_GPIO_PIN		      GPIO_Pin_11		        

//STEP2�ź� 
#define STEP2_GPIO_PORT      GPIOA
#define STEP2_GPIO_CLK       RCC_APB2Periph_GPIOA
#define STEP2_GPIO_PIN       GPIO_Pin_8

//M02�ź�
#define M02_GPIO_PORT        GPIOB
#define M02_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M02_GPIO_PIN         GPIO_Pin_15

//M12�ź� 
#define M12_GPIO_PORT        GPIOB
#define M12_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M12_GPIO_PIN         GPIO_Pin_14

//M22�ź� 
#define M22_GPIO_PORT        GPIOB
#define M22_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M22_GPIO_PIN         GPIO_Pin_13

#endif
#endif
#endif

/*
// SLP�ź�
#define SLP_GPIO_PORT    	  GPIOA
#define SLP_GPIO_CLK 	      RCC_APB2Periph_GPIOA		
#define SLP_GPIO_PIN		    GPIO_Pin_14  

// FLT�ź�
#define FLT_GPIO_PORT    	  GPIOA
#define FLT_GPIO_CLK 	      RCC_APB2Periph_GPIOA		
#define FLT_GPIO_PIN		    GPIO_Pin_13  

// DIR�ź�
#define DIR_GPIO_PORT    	  GPIOA
#define DIR_GPIO_CLK 	      RCC_APB2Periph_GPIOA		
#define DIR_GPIO_PIN		    GPIO_Pin_12                 

// EN�ź�
#define EN_GPIO_PORT    	  GPIOA			              
#define EN_GPIO_CLK 	      RCC_APB2Periph_GPIOA		
#define EN_GPIO_PIN		      GPIO_Pin_11		        

//STEP�ź� 
#define STEP_GPIO_PORT      GPIOA
#define STEP_GPIO_CLK       RCC_APB2Periph_GPIOA
#define STEP_GPIO_PIN       GPIO_Pin_8

//M0�ź�
#define M0_GPIO_PORT        GPIOB
#define M0_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M0_GPIO_PIN         GPIO_Pin_15

//M1�ź� 
#define M1_GPIO_PORT        GPIOB
#define M1_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M1_GPIO_PIN         GPIO_Pin_14

//M2�ź� 
#define M2_GPIO_PORT        GPIOB
#define M2_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M2_GPIO_PIN         GPIO_Pin_13


// SLP2�ź�
#define SLP2_GPIO_PORT    	GPIOB
#define SLP2_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define SLP2_GPIO_PIN		    GPIO_Pin_9  

// FLT2�ź�
#define FLT2_GPIO_PORT    	GPIOB
#define FLT2_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define FLT2_GPIO_PIN		    GPIO_Pin_8  

// DIR2�ź�
#define DIR2_GPIO_PORT    	GPIOB
#define DIR2_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define DIR2_GPIO_PIN		    GPIO_Pin_7                 

// EN2�ź�
#define EN2_GPIO_PORT    	  GPIOB			              
#define EN2_GPIO_CLK 	      RCC_APB2Periph_GPIOB		
#define EN2_GPIO_PIN		    GPIO_Pin_6		        

//STEP2�ź� 
#define STEP2_GPIO_PORT      GPIOB
#define STEP2_GPIO_CLK       RCC_APB2Periph_GPIOB
#define STEP2_GPIO_PIN       GPIO_Pin_5

//M02�ź�
#define M02_GPIO_PORT        GPIOB
#define M02_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M02_GPIO_PIN         GPIO_Pin_4

//M12�ź� 
#define M12_GPIO_PORT        GPIOB
#define M12_GPIO_CLK         RCC_APB2Periph_GPIOB
#define M12_GPIO_PIN         GPIO_Pin_3

//M22�ź� 
#define M22_GPIO_PORT        GPIOA
#define M22_GPIO_CLK         RCC_APB2Periph_GPIOA
#define M22_GPIO_PIN         GPIO_Pin_15
*/
#define ON  0
#define OFF 1

/* ֱ�Ӳ����Ĵ����ķ�������IO */
#define	digitalHi(p,i)		 {p->BSRR=i;}	 //���Ϊ�ߵ�ƽ		
#define digitalLo(p,i)		 {p->BRR=i;}	 //����͵�ƽ
#define digitalToggle(p,i) {p->ODR ^=i;} //�����ת״̬

void MY_GPIO_Config(void);
//void PFO_GPIO_Config(void);

#endif 
