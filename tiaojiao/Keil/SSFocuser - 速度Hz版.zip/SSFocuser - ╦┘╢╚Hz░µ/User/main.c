/**
  ******************************************************************************
  * @file    main.c
  * @author  HeShouSheng(graycode@qq.com)
  * @version V1.0
  * @date    2017-11-20
  * @brief   SS Focuser
  ******************************************************************************
  */ 
	
#include "stm32f10x.h"
#include "stm32f10x_it.h"
#include "stm32f10x_flash.h"
#include "iodef.h"
#include "pfo.h"
#include "at24c02.h"
#include "bsp_ds18b20.h"
#include "bsp_SysTick.h"
#include "bsp_TiMbase.h"
#include "bsp_usart.h"
#include "bsp_usart_blt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stdbool.h"
//64K�ռ䣬��0ҳ-��31ҳ���ڳ���洢����32ҳ-��63ҳ�������ݴ洢����0x0800 8000~0x0800 FFFF��
//#define WriteFlashAddress    ((u32)0x0800FC00)//�洢�����һҳ����ַ��Χ��0x0800 FC00~0x0800 FFFF
typedef union//�ڲ�Flash���ݸ�ʽ
{
	struct
	{
		u8 	IsCurrent; //��ǰҳ
		u8  IsLowPower;
		u8  IsReverse; 		
		u8  SubDivision;
		u16 MotorSpeed;
		u16 DelayCycle;
		u16 DelayCycle2;
		u16 WriteTimes;//��д����
		int	Position;  //�ϴ�λ��
	}CfgData;
	u32 SaveArray[4];
}UnionData; 
UnionData UD;
/*
typedef union//0-3
{
	int	Position;
	u8 SaveArray[4];
}UnionPos; 

UnionPos UP; 

typedef union//�������һҳ����д��������
{
    struct
    {
      u8    IsReverse;//4
			u8    SubDivision;//5
			u16   MotorSpeed;//6,7
    } MotorData;
		u8 SaveArray[4];
}UnionMotor; 
UnionMotor UM;
*/

char  *pVersion = "SSFocuser-B";    //SE-���ڰ�,BT-������,SB-����������,���������޸�

char  *pBTName = "SSFocuser"; //BT SSID

u8  bIsHome         = 0; 
bool  bIsSlpMode    = true;      //Drv8825�Ƿ���˯��ģʽ
bool  bIsLowPower    = true;     //true-�͹���ģʽ
bool  bIsReverse    = false;     //����Ƿ���
bool  bIsReverseRcv = false;
bool  bIsOnChipStore      = true;     //�Ƿ�Ƭ�ϴ洢
u8    uSubdivision = 8;       //�������ϸ��
u8    uSubdivisionRcv = 8;    //�������ϸ��
u16   uSpeedMax  = 2048;		    	//���ת���ٶ�
u16  	uSpeedRcv  = 8;
u16  	uSpeedCur  = 8;
u16  	uSpeedCnt  = 1250;

u16  	uCnt       = 0;
u16   uSCurve[256]={0};       //����������������
u8    uSCntTot=0;                //�����������ݸ���
u8    uSCntCur=0;

//u8    uMoveState = 0;         //�˶�״̬0-Idle,1-Move,2-Slew out&Slew in,3-Align
u8    uIsMoving   =0;	     //�˶�״̬��־0-stop,1-move up,2-move down
int   iStepCount = 0;         //��ǰ����
int   iStepStart = 0;         //�����
int   iStepStop  = 0;         //�����
int   iStepDelt  = 0;					//�����
int   iStepTemp  = 0;					//�����

//bool  bTempAvail  =false;      //�¶��Ƿ����
float fTemperature=-273.15;
//u8    uGetTempCycle=10;
//u8    uGetTempCount=0;

//Active send cycle
u16   uTimerCount=0;
u16   uSecondCount=0;
u16   uDelayCycle=300;//300S����������˯��ģʽ
u16   uDelayCycle2=0;
u16   uDelayCountPrv=0;
u16   uDelayCountPrv2=0;
//u16   uDelayCountPrv3=0;

char  CmdBuff[32] = {0};     //�ظ��ַ���
char  ReplyBuff[128] = {0};  //�ظ��ַ���
char  TmpBuff[4] = {0};

u16   uWriteTimes=0;
u16   uWriteTimesMax=500;//ÿҳ�洢500�λ���һҳ��ѭ���洢
u32   uStartAdress=0x08008000;
u32   uStopAdress =0x0800FC00;
u32   uCurrentAdress=0x08008000;

unsigned char UART_RxPtr_Prv=0;    //�ϴζ�ȡλ��
unsigned char BLTUART_RxPtr_Prv=0; //�ϴζ�ȡλ��
unsigned char UART_RxCmd=0;        //δ���������
unsigned char BLTUART_RxCmd=0;     //δ���������

void delay_us(u32 nTimer)
{
	u32 i=0;
	for(i=0;i<nTimer;i++){
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	}
}
void delay_ms(u32 nTimer)
{
	u32 i=1000*nTimer;
	delay_us(i);
}
bool wait_ms(u16 nTimer,u16 uStartCount)
{
	u16 uCountTmp=0;
	if(uTimerCount<uStartCount)
		uCountTmp=uTimerCount+65535-uStartCount;
	else
		uCountTmp=uTimerCount-uStartCount;	
	if(uCountTmp>=10*nTimer)
		return true;
	else
		return false;
}

u8 Write_Flash_MCU(u32 Address,u32 *buff, u8 len)
{    
	volatile FLASH_Status FLASHStatus;
	//u32 Address = WriteFlashAddress;
	FLASHStatus = FLASH_COMPLETE;
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	//FLASHStatus = FLASH_ErasePage(WriteFlashAddress);
	FLASHStatus = FLASH_ErasePage(Address);
	if(FLASHStatus == FLASH_COMPLETE)
	{
		u8 k;
		for(k=0;(k<len) && (FLASHStatus == FLASH_COMPLETE);k++)
		{
				FLASHStatus = FLASH_ProgramWord(Address, buff[k]);
				Address = Address + 4;
		}        
		FLASH_Lock();
	}
	else
	{
		return 0;
	}
	if(FLASHStatus == FLASH_COMPLETE)
	{
		return 1;
	}
	return 0;
}

void Read_Flash_MCU(u32 Address,u32 *buff, u8 len)
{
	//u32 Address = WriteFlashAddress;
	u8 k;
	for(k=0;k<len;k++)
	{
		buff[k] =  (*(vu32*) Address);
		Address += 4;     
	}
}

//��ʼ����������
void InitCurve(void)
{
	//u16 i=0;
	//uSCurve[0]=15;
	//uSCurve[0]=23;
	//uSCurve[1]=uSubdivision;
	//uSCurve[2]=uSubdivision/2;
	/*
	for(i=3;i<255;)//500�������һ��
	{
		uSCurve[i]=(u16)(uSCurve[i-2]*3/2);
		uSCurve[i+1]=(u16)(uSCurve[i]/2);
		//uSCurve[i]=(u16)(uSCurve[i-2]*2);
		//uSCurve[i+1]=(u16)(uSCurve[i-2]);
		i=i+2;
	}
	*/

	uSCurve[0]=22;
	uSCurve[1]=48;uSCurve[2]=8;
	uSCurve[3]=64;uSCurve[4]=16;
	uSCurve[5]=80;uSCurve[6]=16;
	uSCurve[7]=96;uSCurve[8]=24;
	uSCurve[9]=112;uSCurve[10]=24;
	uSCurve[11]=144;uSCurve[12]=32;
	uSCurve[13]=168;uSCurve[14]=40;
	uSCurve[15]=196;uSCurve[16]=48;
	uSCurve[17]=224;uSCurve[18]=56;
	uSCurve[19]=256;uSCurve[20]=64;
	uSCurve[21]=320;uSCurve[22]=80;
	uSCurve[23]=384;uSCurve[24]=96;
	uSCurve[25]=448;uSCurve[26]=112;	
	uSCurve[27]=512;uSCurve[28]=128;//64
	uSCurve[29]=768;uSCurve[30]=192;
	uSCurve[31]=1000;uSCurve[32]=248;
	uSCurve[33]=1250;uSCurve[34]=320;
	uSCurve[35]=1666;uSCurve[36]=400;
	uSCurve[37]=2000;uSCurve[38]=480;
	uSCurve[39]=2500;uSCurve[40]=640;
	uSCurve[41]=3333;uSCurve[42]=800;
	uSCurve[43]=5000;uSCurve[44]=1200;
	uSCurve[45]=10000;uSCurve[46]=2400;
	/*
	//10000/uspeed
	uSCurve[0]=20;
	uSCurve[1]=208;uSCurve[2]=8;
	uSCurve[3]=156;uSCurve[4]=16;
	uSCurve[5]=125;uSCurve[6]=24;
	uSCurve[7]=104;uSCurve[8]=24;
	uSCurve[9]=89;uSCurve[10]=24;
	uSCurve[11]=69;uSCurve[12]=32;
	uSCurve[13]=59;uSCurve[14]=40;
	uSCurve[15]=51;uSCurve[16]=48;
	uSCurve[17]=44;uSCurve[18]=56;
	uSCurve[19]=39;uSCurve[20]=64;
	uSCurve[21]=31;uSCurve[22]=80;
	uSCurve[23]=26;uSCurve[24]=96;
	uSCurve[25]=22;uSCurve[26]=112;	
	uSCurve[27]=19;uSCurve[28]=128;
	uSCurve[29]=13;uSCurve[30]=192;
	uSCurve[31]=10;uSCurve[32]=248;
	uSCurve[33]=8;uSCurve[34]=320;
	uSCurve[35]=6;uSCurve[36]=400;
	uSCurve[37]=5;uSCurve[38]=480;
	uSCurve[39]=4;uSCurve[40]=640;
	uSCurve[41]=3;uSCurve[42]=800;
	*/
}
//����ΪĬ��ֵ
void SetDefault(void)
{
	bIsLowPower = true;
	bIsReverse = false; 
	uSubdivision = 8;       
	uSpeedMax  = 2048;	
	uDelayCycle=300;
	uDelayCycle2=0;
	iStepCount=0;
	
	uWriteTimes=0;
	uCurrentAdress=uStartAdress;
	/*����д�룬�����Զ��洢
	UP.Position=iStepCount;		
	UM.MotorData.IsReverse=0;
	UM.MotorData.SubDivision=8;
	UM.MotorData.MotorSpeed=1024;
	Write_Flash(UP.SaveArray,0,4);
	Write_Flash(UM.SaveArray,4,4);
	*/
}
//��ȡFlash����ֵ������
void ReadCfg(void)
{
	/*
	Read_Flash(UM.SaveArray,4, 4);
	if((UM.MotorData.IsReverse<0)||(UM.MotorData.IsReverse>1))
		SetDefault();
	else
	{
		bIsReverse = UM.MotorData.IsReverse==0?false:true;
		uSubdivision = UM.MotorData.SubDivision;
		uSpeedMax  = UM.MotorData.MotorSpeed;
		Read_Flash(UP.SaveArray,0, 4);
		iStepCount=UP.Position;
	}
	*/
	u8 i;
	bool bFlag=false;
	for(i=0;i<32;i++)//ɨ���32ҳ
	{
		uCurrentAdress=uStartAdress+1024*i;
		Read_Flash_MCU(uCurrentAdress,UD.SaveArray,4);
		if(UD.CfgData.IsCurrent==111)//�ҵ���ǰ��¼ҳ
		{
			bFlag=true;
			break;
		}
	}	
  if((bFlag==false)||(UD.CfgData.IsReverse<0)||(UD.CfgData.IsReverse>1))//�Ҳ�����ǰ��¼ҳ����δ��ʼ����
		SetDefault();	
	else
	{
		bIsLowPower=UD.CfgData.IsLowPower;
		bIsReverse=UD.CfgData.IsReverse==0?false:true;
		uSubdivision=UD.CfgData.SubDivision;
		uSpeedMax=UD.CfgData.MotorSpeed;
		uDelayCycle=UD.CfgData.DelayCycle;
		uDelayCycle2=UD.CfgData.DelayCycle2;
		uWriteTimes=UD.CfgData.WriteTimes;
		iStepCount=UD.CfgData.Position;
		
		if(uWriteTimes>=uWriteTimesMax)
		{
			UD.CfgData.IsCurrent=0;//����Ϊ�ǵ�ǰҳ
			UD.CfgData.WriteTimes=0;//���ö�д����Ϊ0
			Write_Flash_MCU(uCurrentAdress,UD.SaveArray,4);//������ǰҳ
			//ת����һҳ
			if(uCurrentAdress>=uStopAdress)
				uCurrentAdress=uStartAdress;
			else
				uCurrentAdress=uCurrentAdress+1024;		
		}
	}
	UD.CfgData.IsCurrent=111;//����Ϊ��ǰҳ
	UD.CfgData.WriteTimes++;//���ö�д����+1
}
//������д��Flash�洢
void WriteCfg(void)
{
	/*
	UP.Position=iStepCount;
	Write_Flash(UP.SaveArray,0,4);
	UM.MotorData.IsReverse=bIsReverse==false?0:1;
	UM.MotorData.SubDivision=uSubdivision;
	UM.MotorData.MotorSpeed=uSpeedMax;
	Write_Flash(UM.SaveArray,4,4);
	*/
	UD.CfgData.IsLowPower=bIsLowPower;
	UD.CfgData.IsReverse=bIsReverse==false?0:1;
	UD.CfgData.SubDivision=uSubdivision;
	UD.CfgData.MotorSpeed=uSpeedMax;
	UD.CfgData.DelayCycle=uDelayCycle;
	UD.CfgData.DelayCycle2=uDelayCycle2;
	UD.CfgData.Position=iStepCount;
	Write_Flash_MCU(uCurrentAdress,UD.SaveArray,4);
}
/*
//��ȡFlash����ֵ������
void ReadPosition(void)
{
	Read_Flash(UP.SaveArray,0, 4);
	iStepCount=UP.Position;
}
//��λ��д��Flash�洢
void WritePosition(void)
{
	UP.Position=iStepCount;
	Write_Flash(UP.SaveArray,0,4);
}
//��ȡFlash����ֵ������
void ReadMotorPara(void)
{
	Read_Flash(UM.SaveArray,4, 4);
	bIsReverse = UM.MotorData.IsReverse==0?false:true;
	uSubdivision = UM.MotorData.SubDivision;
	uSpeedMax  = UM.MotorData.MotorSpeed;
}
//���������д��Flash�洢
void WriteMotorPara(void)
{
	UM.MotorData.IsReverse=bIsReverse==false?0:1;
	UM.MotorData.SubDivision=uSubdivision;
	UM.MotorData.MotorSpeed=uSpeedMax;
	Write_Flash(UM.SaveArray,4,4);
}
*/
float GetTemperature(void)
{
	//if(uMoveState==0)//Ϊ�����¶ȶ�ȡ����SystemtickӰ��PWM������״̬�Ŷ�ȡ�¶�
	if(uIsMoving==0)//Ϊ�����¶ȶ�ȡ����SystemtickӰ��PWM������״̬�Ŷ�ȡ�¶�
		fTemperature=DS18B20_Get_Temp();
	return fTemperature;
}
//ͨ��ĳ�����ڷ���
void SendTo(u8 MyComPort,char MyReplyBuff[])
{
	switch(MyComPort)
	{
		case 0:
			printf("%s", MyReplyBuff);
			break;
		case 1:
			BLTUsart_SendString(USART2,MyReplyBuff);
			break;
	}
	memset(MyReplyBuff,0,128);
}
//��������
void SetBluetooth(void)
{
	char  TemBuff[24] = {0};
	sprintf(TemBuff, "AT");
	BLTUsart_SendString(USART2,TemBuff);
	delay_ms(100);
	memset(TemBuff,0,24);
	sprintf(TemBuff, "AT+NAME=%s", CmdBuff+2);
	BLTUsart_SendString(USART2,TemBuff);	
	delay_ms(100);
	memset(TemBuff,0,24);
	sprintf(TemBuff, "AT+RESET");
	BLTUsart_SendString(USART2,TemBuff);
	//Ӳ��������ģ��,Ӳ������ʧ��������
	//GPIO_ResetBits(BRST_GPIO_PORT, BRST_GPIO_PIN);
	delay_ms(500);
	//GPIO_SetBits(BRST_GPIO_PORT, BRST_GPIO_PIN);
}

//���õ������
void SetReverse(void)
{
	bIsReverse = !bIsReverse; 
}
//����ϸ��
void SetDivision(u8 uDrvNum,u8 sMode)
{
	if(uDrvNum==0)
	{
		switch(sMode)
		{
			case 1://000
			{
				GPIO_ResetBits(M2_GPIO_PORT, M2_GPIO_PIN);
				GPIO_ResetBits(M1_GPIO_PORT, M1_GPIO_PIN);
				GPIO_ResetBits(M0_GPIO_PORT, M0_GPIO_PIN);
				break;
			}
			case 2://001
			{
				GPIO_ResetBits(M2_GPIO_PORT, M2_GPIO_PIN);
				GPIO_ResetBits(M1_GPIO_PORT, M1_GPIO_PIN);
				GPIO_SetBits(M0_GPIO_PORT, M0_GPIO_PIN);			
				break;
			}
			case 4://010
			{
				GPIO_ResetBits(M2_GPIO_PORT, M2_GPIO_PIN);	
				GPIO_SetBits(M1_GPIO_PORT, M1_GPIO_PIN);
				GPIO_ResetBits(M0_GPIO_PORT, M0_GPIO_PIN);
				break;
			}
			case 8://011
			{   
				GPIO_ResetBits(M2_GPIO_PORT, M2_GPIO_PIN);
				GPIO_SetBits(M1_GPIO_PORT, M1_GPIO_PIN);
				GPIO_SetBits(M0_GPIO_PORT, M0_GPIO_PIN);	
				break;
			}
			case 16://100
			{
				GPIO_SetBits(M2_GPIO_PORT, M2_GPIO_PIN);	   
				GPIO_ResetBits(M1_GPIO_PORT, M1_GPIO_PIN);
				GPIO_ResetBits(M0_GPIO_PORT, M0_GPIO_PIN);		
				break;
			}
			case 32://111
			{
				GPIO_SetBits(M2_GPIO_PORT, M2_GPIO_PIN);  
				GPIO_SetBits(M1_GPIO_PORT, M1_GPIO_PIN);
				GPIO_SetBits(M0_GPIO_PORT, M0_GPIO_PIN);		
				break;
			}
		}
	}
	else if(uDrvNum==1)
	{
		/*
		switch(sMode)
		{
			case 1://000
			{
				GPIO_ResetBits(M22_GPIO_PORT, M22_GPIO_PIN);
				GPIO_ResetBits(M12_GPIO_PORT, M12_GPIO_PIN);
				GPIO_ResetBits(M02_GPIO_PORT, M02_GPIO_PIN);
				break;
			}
			case 2://001
			{
				GPIO_ResetBits(M22_GPIO_PORT, M22_GPIO_PIN);
				GPIO_ResetBits(M12_GPIO_PORT, M12_GPIO_PIN);
				GPIO_SetBits(M02_GPIO_PORT, M02_GPIO_PIN);			
				break;
			}
			case 4://010
			{
				GPIO_ResetBits(M22_GPIO_PORT, M22_GPIO_PIN);	
				GPIO_SetBits(M12_GPIO_PORT, M12_GPIO_PIN);
				GPIO_ResetBits(M02_GPIO_PORT, M02_GPIO_PIN);
				break;
			}
			case 8://011
			{   
				GPIO_ResetBits(M22_GPIO_PORT, M22_GPIO_PIN);
				GPIO_SetBits(M12_GPIO_PORT, M12_GPIO_PIN);
				GPIO_SetBits(M02_GPIO_PORT, M02_GPIO_PIN);	
				break;
			}
			case 16://100
			{
				GPIO_SetBits(M22_GPIO_PORT, M22_GPIO_PIN);	   
				GPIO_ResetBits(M12_GPIO_PORT, M12_GPIO_PIN);
				GPIO_ResetBits(M02_GPIO_PORT, M02_GPIO_PIN);		
				break;
			}
			case 32://111
			{
				GPIO_SetBits(M22_GPIO_PORT, M22_GPIO_PIN);  
				GPIO_SetBits(M12_GPIO_PORT, M12_GPIO_PIN);
				GPIO_SetBits(M02_GPIO_PORT, M02_GPIO_PIN);		
				break;
			}
		}
		*/
	}
}
//�����ٶ�
void SetSpeed(u16 uSetSpeed)
{
	uSpeedCnt=10000/uSetSpeed;
}
//��ʼ�����
void InitMotor(void)
{
	uIsMoving = 0;
	SetDivision(0,uSubdivision);
	SetSpeed(uSubdivision);
}
//����ת��
void SlewOut(void)//:F+#
{
	//u8 i=0;
	//��ʼ�ٶȣ����ڼ���
	uCnt = 0;
	uSCntCur=0;
	uSpeedCur=uSCurve[uSCntCur*2+1];
	iStepDelt=uSCurve[uSCntCur*2+2];
	SetSpeed(uSpeedCur);
	//GPIO_ResetBits(STEP_GPIO_PORT, STEP_GPIO_PIN);
	//���õ���˶�����
	if(bIsReverse)
		GPIO_ResetBits(DIR_GPIO_PORT, DIR_GPIO_PIN);  
	else
		GPIO_SetBits(DIR_GPIO_PORT, DIR_GPIO_PIN);    		
	//ʹ�����
	//GPIO_ResetBits(EN_GPIO_PORT, EN_GPIO_PIN);
	if(bIsSlpMode)//����˯��
	{
		GPIO_SetBits(SLP_GPIO_PORT, SLP_GPIO_PIN);
		bIsSlpMode=false;
	}
	delay_ms(100);
	uSecondCount=0;
	uIsMoving = 1;//�˶�״̬��־	
}
//����ת��
void SlewIn(void)//:F-#
{	
	//u8 i=0;
	//��ʼ�ٶȣ����ڼ���
	uCnt = 0;
	uSCntCur=0;
	uSpeedCur=uSCurve[uSCntCur*2+1];
	iStepDelt=uSCurve[uSCntCur*2+2];
	SetSpeed(uSpeedCur);
	//GPIO_ResetBits(STEP_GPIO_PORT, STEP_GPIO_PIN);
	//���õ���˶�����
	if(bIsReverse)
		GPIO_SetBits(DIR_GPIO_PORT, DIR_GPIO_PIN);    
	else
		GPIO_ResetBits(DIR_GPIO_PORT, DIR_GPIO_PIN); 
	//ʹ�����
	//GPIO_ResetBits(EN_GPIO_PORT, EN_GPIO_PIN);
	if(bIsSlpMode)//����˯��
	{
		GPIO_SetBits(SLP_GPIO_PORT, SLP_GPIO_PIN);
		bIsSlpMode=false;
	}
	delay_ms(100);
	uSecondCount=0;
	uIsMoving = 2;
}
//ת���̶�����
void MoveTo()
{ 
	if(iStepStop>iStepStart)
	{
		SlewOut();
	}
	else
	{
		SlewIn();		
	}
}

//ֹͣ
void Halt(void)
{
	//if((iStepStop%uSubdivision)!=0)
	//{
	if(uIsMoving==1)
	{
		iStepStop=(iStepCount/uSubdivision+10)*uSubdivision;//10����ֹͣ
	}
	else if(uIsMoving==2)
	{
		iStepStop=(iStepCount/uSubdivision-10)*uSubdivision;
	}
	//}
	//uMoveState = 0;
	//uIsMoving=0;
	//��ֹ���
	//GPIO_SetBits(EN_GPIO_PORT, EN_GPIO_PIN);
	//����˯��ģʽ	
	//GPIO_ResetBits(SLP_GPIO_PORT, SLP_GPIO_PIN);
}

//������һ��
u8 Next(u8 Prv)
{
	if(Prv<255)
		return Prv+1;
	else //255
		return 0;
}
//��ȡһ�����ȥ��ͷβ:#��ָ��ָ����һ������
u8 ReadCmd(unsigned char *RxBuffer,unsigned char *Ptr)
{
	u8 Flag=0,i=0;
	memset(CmdBuff,0,32);
	for(;;)
	{
		//���������жϵ�˳���ܵ���
		if(RxBuffer[*Ptr]==35)//#��������
		{ 
			if(Flag==1)//��������
			{
				CmdBuff[i]=NULL;//û�н�������split���������
				Flag=2;
			}
			else
				Flag=3;
		}
		if(Flag==1)//:��ſ�ʼ��ȡ�����ַ���
		{
			CmdBuff[i]=RxBuffer[*Ptr];
			i++;
		}
		if(RxBuffer[*Ptr]==58)//:
		{
			Flag=1;
			i=0;
		}
		//ѭ����ȡ���ڻ�����
		*Ptr=Next(*Ptr);
		if(Flag>1)//����ѭ��
			break;
	}
	return i;
}
//�����
bool CmdProcess(u8 MyComPort,unsigned char *RxBuffer,unsigned char *Ptr)
{
	if(ReadCmd(RxBuffer,Ptr)<1)
		return false;
	memset(ReplyBuff,0,128);
	if(CmdBuff[0]=='F')//������������F��ͷ
	{
		switch (CmdBuff[1])
		{
			case '?':  //Focuser version
				{
					sprintf(ReplyBuff, ":?%s#\r\n", pVersion);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case '+': 	//Slew Out		 
				{
					iStepStop=(iStepCount/uSubdivision+500)*uSubdivision;//������500����֤500mS�ڲ���ͣ��
					if(uIsMoving == 1)
						;
					else
					{
						sprintf(ReplyBuff, ":+#\r\n");
						SendTo(MyComPort,ReplyBuff);
						Halt();
						while(uIsMoving)//�ȴ���ȫֹͣ
						{
							delay_ms(100);
						}
						iStepStart=iStepCount;//��ʼλ�ã����ڼ���
						SlewOut();
					}
					break;
				}
			case '-':   //Slew In
				{
					iStepStop=(iStepCount/uSubdivision-500)*uSubdivision;//������500����֤500���ڲ���ͣ��
					if(uIsMoving == 2)
						;
					else
					{
						sprintf(ReplyBuff, ":-#\r\n");
						SendTo(MyComPort,ReplyBuff);
						Halt();
						while(uIsMoving)//�ȴ���ȫֹͣ
						{
							delay_ms(100);
						}
						iStepStart=iStepCount;//��ʼλ�ã����ڼ���
						SlewIn();
					}	
					break;
				}
			case 'a': //  			
				{
					sprintf(ReplyBuff,":a%d~%d~%.2f~%d~%d~%d~%d~%d#\r\n", iStepCount/uSubdivision,uIsMoving,GetTemperature(),bIsReverse,uSubdivision,uSpeedMax/uSubdivision,bIsLowPower,bIsOnChipStore);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case 'B': // Busy Status  			
				{
					sprintf(ReplyBuff,":B%d#\r\n", uIsMoving);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case 'b': //Bluetooth setting  			
				{
					sprintf(ReplyBuff, ":b#\r\n");
					SendTo(MyComPort,ReplyBuff);
					SetBluetooth();		
					break;
				}
			case 'D':  //Define current position			
				{
					sprintf(ReplyBuff, ":D#\r\n");
					SendTo(MyComPort,ReplyBuff);
					Halt();
					while(uIsMoving)//�ȴ���ȫֹͣ
					{
						delay_ms(100);
					}
					iStepCount = atoi((char const *)CmdBuff+2)*uSubdivision;
					break;
				}
			case 'I': //		
				{
					sprintf(ReplyBuff, ":I#\r\n");
					SendTo(MyComPort,ReplyBuff);
					//���÷���
					if(bIsOnChipStore != (CmdBuff[2] == '1')?true:false)
					{
						bIsOnChipStore = !bIsOnChipStore;							
					}
					break;
				}
			case 'i': //		
				{
					sprintf(ReplyBuff,":i%d#\r\n",bIsOnChipStore);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case 'L': //		
				{
					sprintf(ReplyBuff, ":L#\r\n");
					SendTo(MyComPort,ReplyBuff);
					Halt();
					while(uIsMoving)//�ȴ���ȫֹͣ
					{
						delay_ms(100);
					}
					//���÷���
					if(bIsLowPower != (CmdBuff[2] == '1')?true:false)
					{
						bIsLowPower = !bIsLowPower;	
						if(!bIsLowPower)
						{
							GPIO_SetBits(SLP_GPIO_PORT, SLP_GPIO_PIN);
							bIsSlpMode=false;
						}
						else
						{
							GPIO_ResetBits(SLP_GPIO_PORT, SLP_GPIO_PIN);
							bIsSlpMode=true;
						}							
					}
					break;
				}
			case 'l': //		
				{
					sprintf(ReplyBuff,":l%d#\r\n",bIsLowPower);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case 'M': //Set Motor subdivision,Speed and Reverse
				{
					sprintf(ReplyBuff, ":M#\r\n");
					SendTo(MyComPort,ReplyBuff);
					//ֹͣ�˶�
					Halt();
					while(uIsMoving)//�ȴ���ȫֹͣ
					{
						delay_ms(100);
					}
					//���÷���
					if(bIsReverse != (CmdBuff[2] == '1')?true:false)
					{
						bIsReverse = !bIsReverse;		
					}
					//����ϸ��
					memset(TmpBuff,0,8);
					TmpBuff[0]=CmdBuff[3];TmpBuff[1]=CmdBuff[4];TmpBuff[2]=CmdBuff[5];
					uSubdivisionRcv = atoi((char const *)TmpBuff+0);
					if(uSubdivisionRcv!=uSubdivision)//��ͬ������
					{
						switch(uSubdivisionRcv)//�ж���Ч��
						{
							case 1:
							case 2:
							case 4:
							case 8:
							case 16:
							case 32:
							{
								//���㵱ǰϸ���µļ���ֵ
								iStepCount = (iStepCount *uSubdivisionRcv)/uSubdivision;
								uSubdivision=uSubdivisionRcv;
								SetDivision(0,uSubdivision);
								break;
							}
						}
					}
					//�����ٶ�
					memset(TmpBuff,0,8);
					TmpBuff[0]=CmdBuff[6];TmpBuff[1]=CmdBuff[7];TmpBuff[2]=CmdBuff[8];
					uSpeedRcv = atoi((char const *)TmpBuff+0)*uSubdivision;
					if(uSpeedRcv!=uSpeedMax)
					{
						if(uSpeedRcv>=uSubdivision)
						{
							uSpeedMax=uSpeedRcv;
						}
					}				
					break;
				}
			case 'm': //Get Subdivision		
				{
					sprintf(ReplyBuff,":m%d~%d~%d#\r\n",bIsReverse,uSubdivision,uSpeedMax/uSubdivision);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case 'P':    //Move command
				{
					sprintf(ReplyBuff, ":P#\r\n");
					SendTo(MyComPort,ReplyBuff);
					Halt();
					while(uIsMoving)//�ȴ���ȫֹͣ
					{
						delay_ms(100);
					}
					iStepStart=iStepCount;//��ʼλ�ã����ڼ���
					iStepStop = atoi((char const *)CmdBuff+2)*uSubdivision;
					if(iStepStart!=iStepStop)//����Ȳ�ִ��
					{
						MoveTo();
					}
					break;
				}
			case 'p':  //Get Position
				{
					sprintf(ReplyBuff,":p%d#\r\n", iStepCount/uSubdivision);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case 'Q': 	//Halt    
				{
					Halt();
					sprintf(ReplyBuff, ":Q#\r\n");
					SendTo(MyComPort,ReplyBuff);				
					break;
				}
			case 'R': //Reverse			
				{
					sprintf(ReplyBuff, ":R#\r\n");
					SendTo(MyComPort,ReplyBuff);
					Halt();
					while(uIsMoving)//�ȴ���ȫֹͣ
					{
						delay_ms(100);
					}
					//���÷���
					if(bIsReverse != (CmdBuff[2] == '1')?true:false)
					{
						bIsReverse = !bIsReverse;		
					}
					break;
				}
			case 'r': //		
				{
					sprintf(ReplyBuff,":r%d#\r\n",bIsReverse);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case 'S':    //�Ӽ�����������
				{
					sprintf(ReplyBuff, ":S#\r\n");
					SendTo(MyComPort,ReplyBuff);
					if (CmdBuff[2] == 'E')//������־���洢����
						WriteCfg();
					else
					{
						if (CmdBuff[2] == 'B')//��ʼ��־����һ��Ϊ���ݸ���
						{
							Halt();//��ֹͣ�����
							while(uIsMoving)//�ȴ���ȫֹͣ
							{
								delay_ms(100);
							}
							uSCntTot=0;
							memset(uSCurve,0,256);
						}
						else if (CmdBuff[2] == 'D')//���ݴ���
							uSCntTot++;
						uSCurve[uSCntTot]=atoi((char const *)CmdBuff+3);
					}
					break;							
				}
			case 's':    //��ӡ�Ӽ�������
				{
					u16 i=0;int ss=0;
					sprintf(ReplyBuff, ":sTotal:%d---#\r\n",uSCurve[0]);
					SendTo(MyComPort,ReplyBuff);
					for(i=0;i<=uSCurve[0];)
					{
						ss=ss+uSCurve[i*2+2];
						sprintf(ReplyBuff, ":s%d,%d,%d#\r\n",uSCurve[i*2+1],uSCurve[i*2+2],ss);
						SendTo(MyComPort,ReplyBuff);
						i++;
					}
					break;
				}
			case 't':   //Get temperature
				{
					sprintf(ReplyBuff,":t%.2f#\r\n", GetTemperature());//����2λС��
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case 'V': //Set Motor Speed
				{
					sprintf(ReplyBuff, ":V#\r\n");
					SendTo(MyComPort,ReplyBuff);
					if (CmdBuff[2] == '+')
					{
						uSpeedMax=uSpeedMax*2;
						if(uSpeedMax<uSubdivision)
								uSpeedMax=uSubdivision;
					}
					else if (CmdBuff[2] == '-')
					{
						uSpeedMax=uSpeedMax/2;
						if(uSpeedMax<=uSubdivision)
								uSpeedMax=uSubdivision;
					}
					else//�����ٶ�
					{
						uSpeedRcv = atoi((char const *)CmdBuff+2)*uSubdivision;
						if(uSpeedRcv!=uSpeedMax)
						{
								uSpeedMax=uSpeedRcv;
						}
					}
					break;
				}
			case 'v': //Get Motor Speed		
				{
					sprintf(ReplyBuff,":v%d#\r\n",uSpeedMax/uSubdivision);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case 'Y':  
				{
					sprintf(ReplyBuff, ":Y#\r\n");
					SendTo(MyComPort,ReplyBuff);
					if(uDelayCycle != atoi((char const *)CmdBuff+2))
					{
						uDelayCycle = atoi((char const *)CmdBuff+2);
					}
					break;
				}
			case 'y': 
				{
					sprintf(ReplyBuff, ":y%d#\r\n",uDelayCycle);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			case 'Z':  
				{
					sprintf(ReplyBuff, ":Z#\r\n");
					SendTo(MyComPort,ReplyBuff);
					if(uDelayCycle2 != atoi((char const *)CmdBuff+2))
					{
						uDelayCycle2 = atoi((char const *)CmdBuff+2);
					}
					break;
				}
			case 'z': 
				{
					sprintf(ReplyBuff, ":z%d#\r\n",uDelayCycle2);
					SendTo(MyComPort,ReplyBuff);
					break;
				}
			default://Unknow Command
				{
					sprintf(ReplyBuff, ":U#\r\n");
					SendTo(MyComPort,ReplyBuff);
					break;
				}
		}
	}
	return true;
}

//������
int main()
{	
	SystemInit();
	
	//SysTick_Init();
	
	MY_GPIO_Config();
	
	TIM1_Init(99,71);//100US��ʱ����10KHz
	
	//TIM2_Init(99,71);//100US��ʱ����10KHz
	
	//TIM3_Init(9999,7199);//1S��ʱ����1Hz
	
	PF_Config();
	
	USART_Config();
	
	//BLT_USART_Config();
	
	//AT24C02
	//I2C_init();	
	
	//��ʼ���¶ȴ�����
	DS18B20_Init();
	DS18B20_Get_Temp();//��һ�ζ�ȡ���ع̶�ֵ
	delay_ms(1000);

	//��ʼ������
	ReadCfg();
	//��ʼ���Ӽ�������
	InitCurve();
	//��ʼ�����
	InitMotor();
	
	if(!bIsLowPower)
	{
		GPIO_SetBits(SLP_GPIO_PORT, SLP_GPIO_PIN);
		bIsSlpMode=false;
	}
	else
	{
		GPIO_ResetBits(SLP_GPIO_PORT, SLP_GPIO_PIN);
		bIsSlpMode=true;
	}

	while(1)
	{	
		//��������1����
		while(UART_RxCmd>0)
		{
			UART_RxCmd--;//���������һ
			CmdProcess(0,UART_RxBuffer,&UART_RxPtr_Prv);
		}	
	/*
	  //��������2����	
	  while(BLTUART_RxCmd>0)
	  { 
			BLTUART_RxCmd--;//���������һ
			CmdProcess(1,BLTUART_RxBuffer,&BLTUART_RxPtr_Prv);
	  }
	*/	
		//�͹���ģʽ�����ʱ��������DRV8825����˯��
		if((bIsLowPower)&&(!bIsSlpMode)&&(uIsMoving==0))
		{
			if(wait_ms(1000,uDelayCountPrv))
			{
				uSecondCount++;
				uDelayCountPrv=uTimerCount;
			}
			if(uSecondCount>=uDelayCycle)
			{
				GPIO_ResetBits(SLP_GPIO_PORT, SLP_GPIO_PIN);
				bIsSlpMode=true;
			}		
		}
		
		//��������ģʽ
		if(uDelayCycle2>0)//ֻ�д�����ŷ��ͻ�
		{
			if(wait_ms(uDelayCycle2,uDelayCountPrv2))
			{	
				sprintf(ReplyBuff,":a%d~%d~%.2f~%d~%d~%d~%d~%d#\r\n", iStepCount/uSubdivision,uIsMoving,GetTemperature(),bIsReverse,uSubdivision,uSpeedMax/uSubdivision,bIsLowPower,bIsOnChipStore);
				printf("%s", ReplyBuff);
				//BLTUsart_SendString(USART2,ReplyBuff);//������֧����������
				memset(ReplyBuff,0,128);		
				uDelayCountPrv2=uTimerCount;
			}
		}	
	}
}

/*********************************************END OF FILE**********************/
